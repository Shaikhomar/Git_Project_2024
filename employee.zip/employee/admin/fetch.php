<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>addemp Page</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    /* Custom styles for full page vertical navbar */
    body, html {
      height: 100%;
      overflow-x: hidden;
    }
    .navbar {
      height: 100vh;
      width: 200px; /* Width of the vertical navbar */
      position: fixed;
      background-color: #343a40; /* Navbar background color */
    }
    .navbar-nav {
      width: 100%;
      font-size: 18px; /* Font size for navbar links */
    }
    .navbar-nav .nav-link {
      padding: 15px 20px; /* Padding for navbar links */
      color: #ffffff; /* Text color */
    }
    .navbar-nav .nav-link:hover {
      background-color: #495057; /* Hover background color */
    }
    .content {
      margin-left: 200px; /* Adjust content margin to accommodate navbar width */
      padding: 20px;
    }
    .table {
    background-color: #ffffff; /* Table background color */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Box shadow for table */
  }
  .table th, .table td {
    vertical-align: middle; /* Center content vertically */
  }
  .btn-view {
    padding: 5px 10px; /* Button padding */
    background-color: #007bff; /* Button background color */
    border: none;
    color: #ffffff; /* Button text color */
    text-decoration: none;
    cursor: pointer;
  }
  .btn-view:hover {
    background-color: #0056b3; /* Button hover background color */
  }
  </style>
</head>
<body>
  <!--logo sathi cha column use kelay-->
  <div class="container text-center">
    <div class="row align-items-start">
      <div class="col">
      
      </div>
      <div class="col">
       <h2 style="color: brown;"> Employee  Management System..!<h2>
      </div>
      <div class="col">
       </div>
    </div>
  </div>

  <!-- Navbar -->
<nav class="navbar navbar-dark bg-dark">
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="fetch.php"sr-only>Employee</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="register.html">Add Employee</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="https://docs.google.com/spreadsheets/d/1DVhLHGFcLz61vwe9V2pBt34D3JcQmVhsDir-8JxJk2g/edit?usp=sharing">Feedback</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="https://mail.google.com/mail/u/0/#inbox">Contact</a>
    </li>
  </ul>
</nav>


<!-- Content -->
<div class="container mt-5">
  <div class="row">
    <div class="col">
      <h2 class="text-center mb-4">Employee List</h2>
      <div class="table-responsive">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "emp_mgt";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        // Fetch data from database
        $sql = "SELECT * FROM euser";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          echo '<table class="table table-bordered table-striped">';
          echo '<thead class="thead-dark">';
          echo '<tr>';
          echo '<th>ID</th>';
          echo '<th>Username</th>';
          echo '<th>Email</th>';
          echo '<th>Gender</th>';
          echo '<th>Skills</th>';
          echo '<th>Country</th>';
          echo '<th>Action</th>';
          echo '</tr>';
          echo '</thead>';
          echo '<tbody>';

          while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row["id"] . '</td>';
            echo '<td>' . $row["username"] . '</td>';
            echo '<td>' . $row["email"] . '</td>';
            echo '<td>' . $row["gender"] . '</td>';
            echo '<td>' . $row["skills"] . '</td>';
            echo '<td>' . $row["country"] . '</td>';
            echo '<td><a href="view.php?id=' . $row["id"] . '" class="btn btn-view" target="_blank">View</a></td>';
            echo '</tr>';
          }

          echo '</tbody>';
          echo '</table>';
        } else {
          echo '<p class="text-center">No employees found.</p>';
        }

        $conn->close();
        ?>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</body>
</html>
